package NGS.NHN.practice.day14.first.ball;

public class Figure {
	
	
	

}
